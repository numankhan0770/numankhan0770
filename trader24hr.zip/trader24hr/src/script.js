// DOM Elements
const loginScreen = document.getElementById('login-screen');
const appScreen = document.getElementById('app-screen');
const loginForm = document.getElementById('login-form');
const winButton = document.getElementById('win-button');
const loseButton = document.getElementById('lose-button');
const resetButton = document.getElementById('reset-button');
const saveExitButton = document.getElementById('save-exit-button');
const logoutButton = document.getElementById('logout-button');
const winCountElement = document.getElementById('win-count');
const loseCountElement = document.getElementById('lose-count');
const winPercentageElement = document.getElementById('win-percentage');
const splashScreen = document.getElementById('splash-screen');
const welcomeSound = document.getElementById('welcome-sound');

// Records
let records = {
  wins: 0,
  losses: 0
};

// Load records from localStorage
function loadRecords() {
  const savedRecords = localStorage.getItem('trader24hr-records');
  if (savedRecords) {
    records = JSON.parse(savedRecords);
    updateUI();
  }
}

// Save records to localStorage
function saveRecords() {
  localStorage.setItem('trader24hr-records', JSON.stringify(records));
}

// Update UI
function updateUI() {
  winCountElement.textContent = records.wins;
  loseCountElement.textContent = records.losses;
  const total = records.wins + records.losses;
  const winPercentage = total > 0 ? ((records.wins / total) * 100).toFixed(2) : 0;
  winPercentageElement.textContent = `${winPercentage}%`;
}

// Hide splash screen and show login screen after animation ends
function showLoginScreen() {
  splashScreen.style.display = 'none';
  loginScreen.style.display = 'block';
}

// Event Listeners
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const pin = document.getElementById('pin').value;

  // Check if the username and PIN match the specified values
  if (username === 'TRADER24HR' && pin === '0770') {
    loginScreen.style.display = 'none';
    appScreen.style.display = 'block';
    loadRecords();
  } else {
    alert('Invalid username or PIN. Please try again.');
  }
});

winButton.addEventListener('click', () => {
  records.wins++;
  updateUI();
  saveRecords();
});

loseButton.addEventListener('click', () => {
  records.losses++;
  updateUI();
  saveRecords();
});

resetButton.addEventListener('click', () => {
  if (confirm('Are you sure you want to reset all records?')) {
    records = { wins: 0, losses: 0 };
    updateUI();
    saveRecords();
  }
});

// Save records and exit the app
saveExitButton.addEventListener('click', () => {
  saveRecords();
  alert('Records saved! The app will now exit.');
  window.close(); // Try to close the app window (works in most cases)
});

// Logout and show login screen
logoutButton.addEventListener('click', () => {
  appScreen.style.display = 'none';
  loginScreen.style.display = 'block';
});

// Play the welcome message audio and then show the login screen
window.onload = () => {
  welcomeSound.play();
  setTimeout(showLoginScreen, 5000); // Wait for the sound to finish playing
};
